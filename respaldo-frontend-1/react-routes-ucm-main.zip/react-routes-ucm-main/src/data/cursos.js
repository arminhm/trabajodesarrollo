const cursos=[
    {
        id:"1",
        name:"Curso de Java",
        url:"java",
        description:"Curso de Java con Springboot"
    },
    {
        id:"2",
        name:"Curso de React",
        url:"react",
        description:"Curso de Basico de React"
    },
    {
        id:"3",
        name:"Curso de React-Native",
        url:"react-native",
        description:"Curso Basico de aplicaciones moviles con react"
    },


];



export {cursos};