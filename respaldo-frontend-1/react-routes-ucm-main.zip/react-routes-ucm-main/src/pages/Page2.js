function Page2(){
    return <>
        <h3>Pagina 2</h3>
        <h3>Ejercicio 1 (Page 1)</h3>
        <p>
            Crea un componente Usuario que por medio de props reciba los datos 
            de cada persona.<br />
            Utiliza un diseño similar al de whatsapps
        </p>
        <h3>Ejercicio 2 (Page 2)</h3>
        <p>
            crea un metodo en services que permita obtener todos los
            paises<br/>
            Crea un componente CardFlag que muestre los datos en una card,
            imagen de la bandera, nombre, capital y otros datos.<br/>
            En el page 2 muestra cada card (4 card por fila) para ello investiga 
            el uso de display:grid en css.
            
        </p>

    </>
}


export {Page2};