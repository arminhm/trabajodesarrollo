function Home(){
    return <>
        <h3>Home </h3>
    </>
}


export {Home};